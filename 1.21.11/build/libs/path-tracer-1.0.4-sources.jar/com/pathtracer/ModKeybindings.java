package com.pathtracer;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

/**
 * Registers the H-key toggle for the path overlay.
 * The keybind can be rebound in Options → Controls → Path Tracer.
 *
 * In MC 1.21.11 the KeyBinding constructor's category parameter changed from
 * a raw String to a KeyBinding.Category object.  Custom categories are created
 * with KeyBinding.Category.create(String) where the String is a translation key
 * that appears in the Controls menu (defined in en_us.json).
 */
@Environment(EnvType.CLIENT)
public class ModKeybindings {

    public static class_304 toggleOverlay;

    public static void register() {
        toggleOverlay = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.path-tracer.toggle",                          // translation key (en_us.json)
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_H,                                   // default: H
                class_304.class_11900.method_74698(class_2960.method_60655("path-tracer", "controls"))  // Controls section
        ));

        // Poll the keybind each tick so it respects repeat-press correctly
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleOverlay.method_1436()) {
                PathRenderer.toggleOverlay();
            }
        });
    }
}
