package com.pathtracer;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11908;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3675;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7842;
import org.lwjgl.glfw.GLFW;

/**
 * Config screen for Path Tracer — three tabs:
 *
 *   General       — mode toggle, shared settings, hotkeys, delete
 *   Path Mode     — footprint size, min/max passes, max age
 *   Explorer Mode — gradient days, max age
 *
 * Clicking a hotkey button enters listen mode; the next key press is bound.
 * Pressing Escape while in listen mode cancels.
 */
@Environment(EnvType.CLIENT)
public class PathTracerConfigScreen extends class_437 {

    // ── Layout ────────────────────────────────────────────────────────────────
    private static final int TAB_Y      = 28;
    private static final int CONTENT_Y  = 56;
    private static final int ROW_HEIGHT = 30;
    private static final int FIELD_W    = 80;
    private static final int FIELD_H    = 20;
    private static final int KEY_BTN_W  = 130;
    private static final String[] FOOTPRINT_LABELS = {"1×1", "3×3", "5×5"};

    // ── State ─────────────────────────────────────────────────────────────────
    private final class_437   parent;
    private int            activeTab          = 0;
    private class_304     activelyRebinding  = null;

    // Working values (survive tab switches; clamped on save)
    private boolean workingExplorerMode;
    private int     workingRenderRadius;
    private int     workingClearRadius;
    private boolean workingTrackOthers;
    private int     workingFootprint;
    private int     workingMinPasses;
    private int     workingMaxPasses;
    private int     workingPathMaxAge;
    private int     workingGradientDays;
    private int     workingExplorerMaxAge;

    public PathTracerConfigScreen(class_437 parent) {
        super(class_2561.method_43470("Path Tracer Settings"));
        this.parent           = parent;
        workingExplorerMode   = PathTracerConfig.explorerMode;
        workingRenderRadius   = PathTracerConfig.renderRadius;
        workingClearRadius    = PathTracerConfig.clearRadius;
        workingTrackOthers    = PathTracerConfig.trackOtherPlayers;
        workingFootprint      = PathTracerConfig.footprintRadius;
        workingMinPasses      = PathTracerConfig.minPassCount;
        workingMaxPasses      = PathTracerConfig.maxPassCount;
        workingPathMaxAge     = PathTracerConfig.maxAgeDays;
        workingGradientDays   = PathTracerConfig.explorerGradientDays;
        workingExplorerMaxAge = PathTracerConfig.explorerMaxAgeDays;
    }

    // ── Init ─────────────────────────────────────────────────────────────────

    @Override
    protected void method_25426() {
        int cx = this.field_22789 / 2;

        // Title
        int tw = field_22793.method_27525(this.field_22785);
        method_37063(new class_7842(cx - tw / 2, 10, tw + 2, 10, this.field_22785, field_22793));

        // Tab buttons — active tab is bolded + underlined and non-clickable
        String[] names = {"General", "Path Mode", "Explorer Mode"};
        int tabW = this.field_22789 / 3;
        for (int i = 0; i < 3; i++) {
            final int tab = i;
            boolean active = (activeTab == i);
            class_4185 btn = class_4185.method_46430(
                            class_2561.method_43470(active ? "§l§n" + names[i] : names[i]),
                            b -> switchTab(tab))
                    .method_46433(i * tabW, TAB_Y)
                    .method_46437(i < 2 ? tabW : this.field_22789 - i * tabW, 20)
                    .method_46431();
            btn.field_22763 = !active;
            method_37063(btn);
        }

        switch (activeTab) {
            case 0 -> buildGeneralTab(cx);
            case 1 -> buildPathTab(cx);
            case 2 -> buildExplorerTab(cx);
        }
    }

    // ── Tab content ───────────────────────────────────────────────────────────

    private void buildGeneralTab(int cx) {
        int y = CONTENT_Y;

        String desc = "Path Mode: heat map of activity.  Explorer Mode: age-based trail.";
        int dw = field_22793.method_1727(desc);
        method_37063(new class_7842(cx - dw / 2, y, dw + 2, 10,
                class_2561.method_43470(desc), field_22793));
        y += 14;

        // Mode toggle
        method_37063(class_4185.method_46430(
                class_2561.method_43470("Mode: " + (workingExplorerMode ? "§bExplorer" : "§aPath Building")),
                btn -> {
                    workingExplorerMode = !workingExplorerMode;
                    btn.method_25355(class_2561.method_43470("Mode: " +
                            (workingExplorerMode ? "§bExplorer" : "§aPath Building")));
                })
                .method_46433(cx - 100, y).method_46437(200, 20).method_46431());
        y += ROW_HEIGHT;

        lf(cx, y, "Render Radius (blocks)", workingRenderRadius,
                PathTracerConfig.RENDER_RADIUS_MIN, PathTracerConfig.RENDER_RADIUS_MAX,
                v -> workingRenderRadius = v);
        y += ROW_HEIGHT;

        lf(cx, y, "Clear Radius (blocks)", workingClearRadius,
                PathTracerConfig.CLEAR_RADIUS_MIN, PathTracerConfig.CLEAR_RADIUS_MAX,
                v -> workingClearRadius = v);
        y += ROW_HEIGHT;

        kb(cx, y, "Show / Hide Overlay", ModKeybindings.toggleOverlay); y += ROW_HEIGHT;
        kb(cx, y, "Clear Nearby Paths",  ModKeybindings.clearArea);     y += ROW_HEIGHT;
        kb(cx, y, "Toggle Mode",          ModKeybindings.toggleMode);    y += ROW_HEIGHT;

        // Other Players
        method_37063(class_4185.method_46430(
                class_2561.method_43470("Other Players: " + (workingTrackOthers ? "§aON" : "§cOFF")),
                btn -> {
                    workingTrackOthers = !workingTrackOthers;
                    btn.method_25355(class_2561.method_43470("Other Players: " +
                            (workingTrackOthers ? "§aON" : "§cOFF")));
                })
                .method_46433(cx - 100, y).method_46437(200, 20).method_46431());
        y += ROW_HEIGHT;

        // Delete All Paths
        method_37063(class_4185.method_46430(class_2561.method_43470("§cDelete All Paths"), btn -> {
            WalkDataStore.getInstance().clearAllDimensions();
            btn.method_25355(class_2561.method_43470("§aAll paths deleted!"));
            btn.field_22763 = false;
        }).method_46433(cx - 100, y).method_46437(200, 20).method_46431());
        y += ROW_HEIGHT;

        done(cx, y);
    }

    private void buildPathTab(int cx) {
        int y = CONTENT_Y;

        // Footprint Size cycle button
        lbl(cx, y - 10, "Footprint Size");
        method_37063(class_4185.method_46430(
                class_2561.method_43470(FOOTPRINT_LABELS[workingFootprint]),
                btn -> {
                    workingFootprint = (workingFootprint + 1) % 3;
                    btn.method_25355(class_2561.method_43470(FOOTPRINT_LABELS[workingFootprint]));
                })
                .method_46433(cx - FIELD_W / 2, y).method_46437(FIELD_W, FIELD_H).method_46431());
        y += ROW_HEIGHT;

        lf(cx, y, "Min Passes", workingMinPasses,
                PathTracerConfig.PASS_COUNT_MIN, PathTracerConfig.PASS_COUNT_MAX,
                v -> workingMinPasses = v);
        y += ROW_HEIGHT;

        lf(cx, y, "Max Passes", workingMaxPasses,
                PathTracerConfig.PASS_COUNT_MIN, PathTracerConfig.PASS_COUNT_MAX,
                v -> workingMaxPasses = v);
        y += ROW_HEIGHT;

        lf(cx, y, "Max Age — Path Mode (days)", workingPathMaxAge,
                PathTracerConfig.MAX_AGE_DAYS_MIN, PathTracerConfig.MAX_AGE_DAYS_MAX,
                v -> workingPathMaxAge = v);
        y += ROW_HEIGHT;

        done(cx, y);
    }

    private void buildExplorerTab(int cx) {
        int y = CONTENT_Y;

        lf(cx, y, "Gradient Days (max 14)", workingGradientDays,
                PathTracerConfig.EXPLORER_GRADIENT_MIN, PathTracerConfig.EXPLORER_GRADIENT_MAX,
                v -> workingGradientDays = v);
        y += ROW_HEIGHT;

        lf(cx, y, "Max Age — Explorer Mode (days)", workingExplorerMaxAge,
                PathTracerConfig.EXPLORER_MAX_AGE_MIN, PathTracerConfig.EXPLORER_MAX_AGE_MAX,
                v -> workingExplorerMaxAge = v);
        y += ROW_HEIGHT;

        done(cx, y);
    }

    // ── Widget helpers ────────────────────────────────────────────────────────

    /** Centered label at y. */
    private void lbl(int cx, int y, String text) {
        int w = field_22793.method_1727(text);
        method_37063(new class_7842(cx - w / 2, y, w + 2, 10,
                class_2561.method_43470(text), field_22793));
    }

    /** Label at y-10, text field at y. Live setter called as user types. */
    private void lf(int cx, int y, String label, int initial, int min, int max, IntSetter setter) {
        lbl(cx, y - 10, label);
        class_342 f = new class_342(
                field_22793, cx - FIELD_W / 2, y, FIELD_W, FIELD_H, class_2561.method_43473());
        f.method_1880(5);
        f.method_1852(String.valueOf(initial));
        f.method_1890(s -> s.matches("\\d*"));
        f.method_1863(s -> {
            try { setter.set(Integer.parseInt(s)); }
            catch (NumberFormatException ignored) {}
        });
        method_37063(f);
    }

    /** Label at y-10, hotkey button at y. */
    private void kb(int cx, int y, String label, class_304 binding) {
        lbl(cx, y - 10, label);
        boolean listening = (activelyRebinding == binding);
        method_37063(class_4185.method_46430(
                listening ? class_2561.method_43470("§ePress a key…") : binding.method_16007(),
                btn -> {
                    activelyRebinding = (activelyRebinding == binding) ? null : binding;
                    switchTab(activeTab);
                })
                .method_46433(cx - KEY_BTN_W / 2, y).method_46437(KEY_BTN_W, FIELD_H).method_46431());
    }

    private void done(int cx, int y) {
        method_37063(class_4185.method_46430(class_2561.method_43470("Done"), btn -> saveAndClose())
                .method_46433(cx - 75, y).method_46437(150, 20).method_46431());
    }

    // ── Key capture ───────────────────────────────────────────────────────────

    @Override
    public boolean method_25404(class_11908 input) {
        if (activelyRebinding != null) {
            if (input.comp_4795() != GLFW.GLFW_KEY_ESCAPE) {
                activelyRebinding.method_1422(class_3675.method_15985(input));
                class_304.method_1426();
                if (field_22787 != null) field_22787.field_1690.method_1640();
            }
            activelyRebinding = null;
            switchTab(activeTab);
            return true;
        }
        return super.method_25404(input);
    }

    // ── Navigation ────────────────────────────────────────────────────────────

    private void switchTab(int tab) {
        activeTab = tab;
        method_41843();
    }

    private void saveAndClose() {
        PathTracerConfig.explorerMode         = workingExplorerMode;
        PathTracerConfig.renderRadius         = clamp(workingRenderRadius, PathTracerConfig.RENDER_RADIUS_MIN, PathTracerConfig.RENDER_RADIUS_MAX);
        PathTracerConfig.clearRadius          = clamp(workingClearRadius,  PathTracerConfig.CLEAR_RADIUS_MIN,  PathTracerConfig.CLEAR_RADIUS_MAX);
        PathTracerConfig.trackOtherPlayers    = workingTrackOthers;
        PathTracerConfig.footprintRadius      = workingFootprint;
        PathTracerConfig.minPassCount         = clamp(workingMinPasses, PathTracerConfig.PASS_COUNT_MIN, PathTracerConfig.PASS_COUNT_MAX);
        PathTracerConfig.maxPassCount         = Math.max(PathTracerConfig.minPassCount,
                clamp(workingMaxPasses, PathTracerConfig.PASS_COUNT_MIN, PathTracerConfig.PASS_COUNT_MAX));
        PathTracerConfig.maxAgeDays           = clamp(workingPathMaxAge,     PathTracerConfig.MAX_AGE_DAYS_MIN,       PathTracerConfig.MAX_AGE_DAYS_MAX);
        PathTracerConfig.explorerGradientDays = clamp(workingGradientDays,   PathTracerConfig.EXPLORER_GRADIENT_MIN,  PathTracerConfig.EXPLORER_GRADIENT_MAX);
        PathTracerConfig.explorerMaxAgeDays   = clamp(workingExplorerMaxAge, PathTracerConfig.EXPLORER_MAX_AGE_MIN,   PathTracerConfig.EXPLORER_MAX_AGE_MAX);
        PathTracerConfig.save();
        method_25419();
    }

    private static int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override
    public void method_25419() {
        if (field_22787 != null) field_22787.method_1507(parent);
    }

    @FunctionalInterface private interface IntSetter { void set(int v); }
}
