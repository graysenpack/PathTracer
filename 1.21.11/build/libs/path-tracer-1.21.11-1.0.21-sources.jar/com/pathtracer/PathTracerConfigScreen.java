package com.pathtracer;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7842;

/**
 * Config screen for Path Tracer, opened via Mod Menu.
 *
 * Each setting is a labelled text field. Values are parsed and clamped
 * when Done is pressed; invalid or empty entries revert to the value
 * the screen opened with.
 *
 * Rows (top to bottom):
 *   Min Walk Count · Max Walk Count · Render Radius · Max Age · Clear Radius
 *
 * Buttons:
 *   Done                 — save & close
 *   Clear All Dimensions — wipe all dimension data for the current world
 */
@Environment(EnvType.CLIENT)
public class PathTracerConfigScreen extends class_437 {

    private static final int ROW_HEIGHT   = 34;
    private static final int FIRST_ROW_Y  = 100;
    private static final int FIELD_W      = 80;
    private static final int FIELD_H      = 20;

    private final class_437 parent;

    // Values the screen was opened with — used as fallback if a field is invalid.
    private final int[] initialValues = {
        PathTracerConfig.minWalkThreshold,
        PathTracerConfig.maxWalkCount,
        PathTracerConfig.renderRadius,
        PathTracerConfig.maxAgeDays,
        PathTracerConfig.clearRadius,
    };

    private final int[] mins = {
        PathTracerConfig.MIN_WALK_THRESHOLD_MIN,
        PathTracerConfig.MAX_WALK_COUNT_MIN,
        PathTracerConfig.RENDER_RADIUS_MIN,
        PathTracerConfig.MAX_AGE_DAYS_MIN,
        PathTracerConfig.CLEAR_RADIUS_MIN,
    };

    private final int[] maxs = {
        PathTracerConfig.MIN_WALK_THRESHOLD_MAX,
        PathTracerConfig.MAX_WALK_COUNT_MAX,
        PathTracerConfig.RENDER_RADIUS_MAX,
        PathTracerConfig.MAX_AGE_DAYS_MAX,
        PathTracerConfig.CLEAR_RADIUS_MAX,
    };

    private final String[] labels = {
        "Min Walk Count",
        "Max Walk Count",
        "Render Radius (blocks)",
        "Max Age (in-game days)",
        "Clear Radius (blocks)",
    };

    private final class_342[] fields = new class_342[5];
    private boolean trackOtherPlayers;

    public PathTracerConfigScreen(class_437 parent) {
        super(class_2561.method_43470("Path Tracer Settings"));
        this.parent            = parent;
        this.trackOtherPlayers = PathTracerConfig.trackOtherPlayers;
    }

    @Override
    protected void method_25426() {
        int cx = this.field_22789 / 2;

        // Title
        int titleW = field_22793.method_27525(this.field_22785);
        method_37063(new class_7842(cx - titleW / 2, 12, titleW + 2, 10,
                this.field_22785, field_22793));

        // Description lines
        String[] desc = {
            "Path Tracer counts the block you stand on + each of",
            "the 8 surrounding blocks when you walk.",
            "Min and Max Walk Count is divided by 3 per pass.",
            "Ex. 3 trips over a block = 9 count."
        };
        for (int i = 0; i < desc.length; i++) {
            int dw = field_22793.method_1727(desc[i]);
            method_37063(new class_7842(cx - dw / 2, 30 + i * 11, dw + 2, 10,
                    class_2561.method_43470(desc[i]), field_22793));
        }

        // Setting rows — one text field per row
        for (int i = 0; i < 5; i++) {
            int y = rowY(i);

            // Centered label
            int lw = field_22793.method_1727(labels[i]);
            method_37063(new class_7842(cx - lw / 2, y - 12, lw + 2, 10,
                    class_2561.method_43470(labels[i]), field_22793));

            // Text field (digits only)
            class_342 field = new class_342(
                    field_22793, cx - FIELD_W / 2, y, FIELD_W, FIELD_H, class_2561.method_43473());
            field.method_1880(5);
            field.method_1852(String.valueOf(initialValues[i]));
            field.method_1890(s -> s.matches("\\d*"));
            fields[i] = field;
            method_37063(field);
        }

        // Track Other Players toggle
        int toggleY = rowY(4) + FIELD_H + 10;
        method_37063(
                class_4185.method_46430(
                        class_2561.method_43470("Track Other Players: " + (trackOtherPlayers ? "§aON" : "§cOFF")),
                        btn -> {
                            trackOtherPlayers = !trackOtherPlayers;
                            btn.method_25355(class_2561.method_43470("Track Other Players: "
                                    + (trackOtherPlayers ? "§aON" : "§cOFF")));
                        })
                        .method_46433(cx - 100, toggleY)
                        .method_46437(200, 20)
                        .method_46431());

        // Buttons
        int btnY  = toggleY + 28;
        int btnW  = (this.field_22789 / 2) - 8;
        int doneX = cx - btnW - 4;
        int clrX  = cx + 4;

        method_37063(
                class_4185.method_46430(class_2561.method_43470("Done"), btn -> saveAndClose())
                        .method_46433(doneX, btnY).method_46437(btnW, 20).method_46431());

        method_37063(
                class_4185.method_46430(class_2561.method_43470("§cClear All Dimensions"), btn -> {
                    WalkDataStore.getInstance().clearAllDimensions();
                    btn.method_25355(class_2561.method_43470("§aAll data cleared!"));
                    btn.field_22763 = false;
                }).method_46433(clrX, btnY).method_46437(btnW, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private int rowY(int i) { return FIRST_ROW_Y + i * ROW_HEIGHT; }

    private int parseField(int index) {
        try {
            String text = fields[index].method_1882().trim();
            if (text.isEmpty()) return initialValues[index];
            return Math.max(mins[index], Math.min(maxs[index], Integer.parseInt(text)));
        } catch (NumberFormatException e) {
            return initialValues[index];
        }
    }

    private void saveAndClose() {
        PathTracerConfig.minWalkThreshold = parseField(0);
        PathTracerConfig.maxWalkCount     = parseField(1);
        PathTracerConfig.renderRadius     = parseField(2);
        PathTracerConfig.maxAgeDays       = parseField(3);
        PathTracerConfig.clearRadius       = parseField(4);
        PathTracerConfig.trackOtherPlayers = trackOtherPlayers;
        PathTracerConfig.save();
        method_25419();
    }

    @Override
    public void method_25419() {
        if (field_22787 != null) field_22787.method_1507(parent);
    }
}
