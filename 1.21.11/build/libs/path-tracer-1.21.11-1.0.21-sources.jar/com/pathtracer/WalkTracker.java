package com.pathtracer;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_746;
import net.minecraft.class_7923;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Listens to client ticks and records which block the player (and optionally
 * other nearby players) is walking on.
 *
 * Tracking rules (applied to both local and other players):
 *   - Must be on the ground (not jumping/falling)
 *   - Not swimming
 *   - Not riding a vehicle
 *   - Not in creative/spectator flight or spectator mode
 *
 * Other-player tracking is opt-in via PathTracerConfig.trackOtherPlayers.
 * Data is stored in the same walkMap so shared paths naturally accumulate.
 */
@Environment(EnvType.CLIENT)
public class WalkTracker {

    private static class_2338 lastTrackedPos = null;

    // Last recorded ground position per other player — avoids recording the
    // same position every tick when a player stands still.
    private static final Map<UUID, class_2338> otherPlayerLastPos = new HashMap<>();

    private static final int SAVE_INTERVAL_TICKS  = 200;   // every 10 s
    private static final int PRUNE_INTERVAL_TICKS = 6000;  // every 5 min
    private static final int FOOTPRINT_RADIUS     = 1;

    private static int saveTimer  = 0;
    private static int pruneTimer = 0;

    public static void register() {

        // ── World join ────────────────────────────────────────────────────────
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            String worldId     = resolveWorldId(client);
            String dimensionId = client.field_1687 != null
                    ? client.field_1687.method_27983().method_29177().toString()
                    : "minecraft:overworld";
            WalkDataStore.getInstance().loadForWorld(worldId, dimensionId);
            lastTrackedPos = null;
            otherPlayerLastPos.clear();
            saveTimer  = 0;
            pruneTimer = 0;
        });

        // ── World disconnect ──────────────────────────────────────────────────
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            WalkDataStore.getInstance().saveData();
            WalkDataStore.getInstance().clear();
            lastTrackedPos = null;
            otherPlayerLastPos.clear();
        });

        // ── Per-tick tracking ─────────────────────────────────────────────────
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            class_746 player = client.field_1724;
            if (player == null || client.field_1687 == null) return;

            // Detect dimension changes (portal travel) and swap data stores.
            String dimensionId = client.field_1687.method_27983().method_29177().toString();
            WalkDataStore store = WalkDataStore.getInstance();
            if (!dimensionId.equals(store.getCurrentDimensionId())) {
                store.switchDimension(dimensionId);
                lastTrackedPos = null;
                otherPlayerLastPos.clear();
            }

            long currentGameDay = client.field_1687.method_75260() / 24000L;

            // ── Local player ─────────────────────────────────────────────────
            if (player.method_24828() && !player.method_5681()
                    && !player.method_5765() && !player.method_31549().field_7479) {
                class_2338 groundPos = resolveGroundPos(player.method_24515(), client.field_1687.method_8320(player.method_24515()), client);
                if (!groundPos.equals(lastTrackedPos)) {
                    lastTrackedPos = groundPos;
                    recordIfAllowed(groundPos, store, currentGameDay, client);
                }
            }

            // ── Other players ─────────────────────────────────────────────────
            if (WalkDataStore.TRACK_OTHER_PLAYERS) {
                for (class_1657 other : client.field_1687.method_18456()) {
                    if (other == player || other.method_7325()) continue;
                    if (!other.method_24828() || other.method_5681()
                            || other.method_5765() || other.method_31549().field_7479) continue;

                    class_2338 groundPos = resolveGroundPos(other.method_24515(), client.field_1687.method_8320(other.method_24515()), client);
                    UUID uuid = other.method_5667();
                    if (groundPos.equals(otherPlayerLastPos.get(uuid))) continue;
                    otherPlayerLastPos.put(uuid, groundPos);
                    recordIfAllowed(groundPos, store, currentGameDay, client);
                }
            }

            // ── Periodic save / prune ─────────────────────────────────────────
            if (++saveTimer >= SAVE_INTERVAL_TICKS) {
                saveTimer = 0;
                store.saveData();
            }
            if (++pruneTimer >= PRUNE_INTERVAL_TICKS) {
                pruneTimer = 0;
                store.pruneExpiredData(currentGameDay);
            }
        });
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /** Determine the actual ground block, accounting for short/sink blocks. */
    private static class_2338 resolveGroundPos(class_2338 feetPos, class_2680 feetBlock,
                                              class_310 client) {
        boolean feetHasCollision = !feetBlock.method_26215()
                && feetBlock.method_26227().method_15769()
                && !feetBlock.method_26220(client.field_1687, feetPos).method_1110();
        return feetHasCollision ? feetPos : feetPos.method_10074();
    }

    /** Record a 3×3 footprint if the ground block is not on the ignore list. */
    private static void recordIfAllowed(class_2338 groundPos, WalkDataStore store,
                                         long currentGameDay, class_310 client) {
        String blockId = class_7923.field_41175
                .method_10221(client.field_1687.method_8320(groundPos).method_26204()).toString();
        if (WalkDataStore.IGNORED_BLOCKS.contains(blockId)) return;
        for (int dx = -FOOTPRINT_RADIUS; dx <= FOOTPRINT_RADIUS; dx++) {
            for (int dz = -FOOTPRINT_RADIUS; dz <= FOOTPRINT_RADIUS; dz++) {
                store.recordWalk(groundPos.method_10069(dx, 0, dz), currentGameDay);
            }
        }
    }

    /**
     * Build a stable identifier for the current world/server so each gets its
     * own save directory.
     *   - Single-player: "sp_<level name>"
     *   - Multiplayer:   "mp_<server address>"
     */
    private static String resolveWorldId(class_310 client) {
        if (client.method_1542() && client.method_1576() != null) {
            String levelName = client.method_1576().method_27728().method_150();
            return "sp_" + levelName;
        }
        if (client.method_1558() != null) {
            return "mp_" + client.method_1558().field_3761;
        }
        return "unknown_world";
    }
}
