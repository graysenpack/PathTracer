package com.pathtracer;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7842;

/**
 * Config screen for Path Tracer, opened via Mod Menu.
 *
 * Uses only proper MC widget objects (TextWidget + ButtonWidget) so that
 * all text goes through the standard widget render path.  Direct
 * DrawContext.drawCenteredTextWithShadow() calls were invisible in
 * environments with Architectury / Blur+ mixins active.
 *
 * Text widgets are manually centered by measuring text width via
 * textRenderer.getWidth() — alignCenter() is not available in 1.21.1.
 *
 * Layout per row (ROW_HEIGHT = 40 px):
 *
 *   y - 12  ── TextWidget label (centred)
 *   y       ── [−]  TextWidget value  [+]
 */
@Environment(EnvType.CLIENT)
public class PathTracerConfigScreen extends class_437 {

    private static final int ROW_HEIGHT  = 40;
    private static final int FIRST_ROW_Y = 118;
    private static final int BTN_W       = 20;
    private static final int BTN_H       = 20;
    // Fixed width for value display — wide enough for up to 3 digits
    private static final int VALUE_W     = 40;
    // Gap between ±  buttons and the value label
    private static final int GAP         = 6;

    private final class_437 parent;

    // Working copies — written to config only when Done is pressed
    private int minWalkThreshold;
    private int maxWalkCount;
    private int renderRadius;
    private int maxAgeDays;

    // References to value TextWidgets so we can update them on ±
    private class_7842[] valueWidgets;

    public PathTracerConfigScreen(class_437 parent) {
        super(class_2561.method_43470("Path Tracer Settings"));
        this.parent = parent;
        this.minWalkThreshold = PathTracerConfig.minWalkThreshold;
        this.maxWalkCount     = PathTracerConfig.maxWalkCount;
        this.renderRadius     = PathTracerConfig.renderRadius;
        this.maxAgeDays       = PathTracerConfig.maxAgeDays;
    }

    @Override
    protected void method_25426() {
        int cx = this.field_22789 / 2;
        valueWidgets = new class_7842[4];

        // Title widget — manually centered
        int titleW = field_22793.method_27525(this.field_22785);
        method_37063(
                new class_7842(cx - titleW / 2, 12, titleW + 2, 10,
                        this.field_22785, field_22793));

        // Description lines
        String[] desc = {
            "Path Tracer counts the block you stand on + each of",
            "the 8 surrounding blocks when you walk.",
            "Min and Max Walk Count is divided by 3 per pass.",
            "Ex. 3 trips over a block = 9 count."
        };
        for (int i = 0; i < desc.length; i++) {
            int dw = field_22793.method_1727(desc[i]);
            method_37063(new class_7842(
                    cx - dw / 2, 30 + i * 11, dw + 2, 10,
                    class_2561.method_43470(desc[i]), field_22793));
        }

        // Setting rows
        addSettingRow(0, cx, "Min Walk Count",
                PathTracerConfig.MIN_WALK_THRESHOLD_MIN,
                PathTracerConfig.MIN_WALK_THRESHOLD_MAX,
                () -> minWalkThreshold,
                v  -> minWalkThreshold = v);

        addSettingRow(1, cx, "Max Walk Count",
                PathTracerConfig.MAX_WALK_COUNT_MIN,
                PathTracerConfig.MAX_WALK_COUNT_MAX,
                () -> maxWalkCount,
                v  -> maxWalkCount = v);

        addSettingRow(2, cx, "Render Radius (blocks)",
                PathTracerConfig.RENDER_RADIUS_MIN,
                PathTracerConfig.RENDER_RADIUS_MAX,
                () -> renderRadius,
                v  -> renderRadius = v);

        addSettingRow(3, cx, "Max Age (in-game days)",
                PathTracerConfig.MAX_AGE_DAYS_MIN,
                PathTracerConfig.MAX_AGE_DAYS_MAX,
                () -> maxAgeDays,
                v  -> maxAgeDays = v);

        // Done button
        int doneY = rowY(3) + BTN_H + 18;
        method_37063(
                class_4185.method_46430(class_2561.method_43470("Done"), btn -> saveAndClose())
                        .method_46433(cx - 75, doneY)
                        .method_46437(150, 20)
                        .method_46431());
    }

    // ── Row builder ───────────────────────────────────────────────────────────

    private void addSettingRow(int index, int cx, String label,
                               int min, int max,
                               IntSupplier getter, IntConsumer setter) {
        int y = rowY(index);

        // Label — manually centered
        int labelW = field_22793.method_1727(label);
        method_37063(
                new class_7842(cx - labelW / 2, y - 12, labelW + 2, 10,
                        class_2561.method_43470(label), field_22793));

        // Minus button
        method_37063(
                class_4185.method_46430(class_2561.method_43470("−"), btn -> {
                    setter.accept(clamp(getter.get() - 1, min, max));
                    valueWidgets[index].method_25355(
                            class_2561.method_43470(String.valueOf(getter.get())));
                })
                .method_46433(cx - BTN_W - VALUE_W / 2 - GAP, y)
                .method_46437(BTN_W, BTN_H)
                .method_46431());

        // Value display — fixed-width widget centred between the two buttons
        class_7842 vw = new class_7842(cx - VALUE_W / 2, y + 6, VALUE_W, 10,
                class_2561.method_43470(String.valueOf(getter.get())), field_22793);
        valueWidgets[index] = vw;
        method_37063(vw);

        // Plus button
        method_37063(
                class_4185.method_46430(class_2561.method_43470("+"), btn -> {
                    setter.accept(clamp(getter.get() + 1, min, max));
                    valueWidgets[index].method_25355(
                            class_2561.method_43470(String.valueOf(getter.get())));
                })
                .method_46433(cx + VALUE_W / 2 + GAP, y)
                .method_46437(BTN_W, BTN_H)
                .method_46431());
    }

    // ── Render ────────────────────────────────────────────────────────────────

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        // All text is handled by TextWidget / ButtonWidget — no direct
        // drawCenteredTextWithShadow calls needed or used.
        super.method_25394(context, mouseX, mouseY, delta);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private int rowY(int i) {
        return FIRST_ROW_Y + i * ROW_HEIGHT;
    }

    private void saveAndClose() {
        PathTracerConfig.minWalkThreshold = minWalkThreshold;
        PathTracerConfig.maxWalkCount     = maxWalkCount;
        PathTracerConfig.renderRadius     = renderRadius;
        PathTracerConfig.maxAgeDays       = maxAgeDays;
        PathTracerConfig.save();
        method_25419();
    }

    private static int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }

    @Override
    public void method_25419() {
        if (field_22787 != null) field_22787.method_1507(parent);
    }

    @FunctionalInterface private interface IntSupplier { int get(); }
    @FunctionalInterface private interface IntConsumer  { void accept(int v); }
}
