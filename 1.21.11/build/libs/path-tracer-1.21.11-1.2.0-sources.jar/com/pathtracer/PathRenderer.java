package com.pathtracer;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_12249;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Renders a colored overlay on top of blocks the player has walked on.
 *
 * Color gradient (all values tweakable in WalkDataStore):
 *   - Below MIN_WALK_THRESHOLD  →  invisible
 *   - At MIN_WALK_THRESHOLD     →  faint green   (0,   255, 0, alpha ~50)
 *   - At MAX_WALK_COUNT         →  bright red    (255,   0, 0, alpha ~180)
 *
 * Iris shader compatibility: registers on END_MAIN instead of BEFORE_TRANSLUCENT
 * so the overlay draws after Iris's gbuffer/composite passes, using the same
 * VertexConsumerProvider that vanilla uses for debug layers.
 */
@Environment(EnvType.CLIENT)
public class PathRenderer {

    private static boolean overlayEnabled = true;

    public static void toggleOverlay() {
        overlayEnabled = !overlayEnabled;
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            String state = overlayEnabled ? "§aEnabled" : "§cDisabled";
            client.field_1724.method_7353(class_2561.method_43470("[PathTracer] Overlay " + state), true);
        }
    }

    public static boolean isOverlayEnabled() {
        return overlayEnabled;
    }

    public static void register() {
        // Tell Iris to route our pipeline through its BASIC program so it is
        // composited correctly rather than discarded or overwritten.
        // Using reflection avoids a compile-time dependency on the Iris jar.
        if (FabricLoader.getInstance().isModLoaded("iris")) {
            assignIrisPipeline();
        }

        WorldRenderEvents.END_MAIN.register(context -> renderOverlay(context));
    }

    private static void assignIrisPipeline() {
        try {
            Class<?> apiClass     = Class.forName("net.irisshaders.iris.api.v0.IrisApi");
            Class<?> programClass = Class.forName("net.irisshaders.iris.api.v0.IrisProgram");
            Object   api          = apiClass.getMethod("getInstance").invoke(null);
            Object   basic        = programClass.getField("BASIC").get(null);
            apiClass.getMethod("assignPipeline",
                            com.mojang.blaze3d.pipeline.RenderPipeline.class,
                            programClass)
                    .invoke(api, class_12249.method_76019().method_73243(), basic);
        } catch (Exception ignored) {}
    }

    // ── Core render logic ─────────────────────────────────────────────────────

    private static void renderOverlay(WorldRenderContext context) {
        if (!overlayEnabled) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return;

        class_4587 matrices = context.matrices();
        if (matrices == null) return;

        Map<class_2338, WalkData> walkMap = WalkDataStore.getInstance().getWalkMap();
        if (walkMap.isEmpty()) return;

        boolean explorerMode = WalkDataStore.EXPLORER_MODE;
        long currentGameDay  = client.field_1687.method_75260() / 24000L;

        class_243 camPos = context.worldState().field_63082.field_63078;
        class_2338 playerPos = client.field_1724.method_24515();
        int      radius   = WalkDataStore.RENDER_RADIUS;
        int      minWalks = explorerMode ? 1 : WalkDataStore.MIN_WALK_THRESHOLD;

        List<Map.Entry<class_2338, WalkData>> toRender = new ArrayList<>();
        for (Map.Entry<class_2338, WalkData> entry : walkMap.entrySet()) {
            class_2338 pos  = entry.getKey();
            WalkData data = entry.getValue();

            if (data.getCount() < minWalks) continue;
            if (Math.abs(pos.method_10263() - playerPos.method_10263()) > radius) continue;
            if (Math.abs(pos.method_10260() - playerPos.method_10260()) > radius) continue;

            toRender.add(entry);
        }
        if (toRender.isEmpty()) return;

        var layer = class_12249.method_76019();
        class_4588 vertexConsumer = context.consumers().method_73477(layer);

        matrices.method_22903();
        matrices.method_22904(-camPos.field_1352, -camPos.field_1351, -camPos.field_1350);
        Matrix4f mat = matrices.method_23760().method_23761();

        for (Map.Entry<class_2338, WalkData> entry : toRender) {
            class_2338 pos  = entry.getKey();
            WalkData data = entry.getValue();

            int[] color = explorerMode
                    ? computeExplorerColor(currentGameDay - data.getLastGameDay())
                    : computeColor(data.getCount());
            int   r = color[0], g = color[1], b = color[2], a = color[3];

            float x1 = pos.method_10263();
            float y  = pos.method_10264() + 1.002f;
            float z1 = pos.method_10260();
            float x2 = x1 + 1.0f;
            float z2 = z1 + 1.0f;

            vertexConsumer.method_22918(mat, x1, y, z1).method_1336(r, g, b, a);
            vertexConsumer.method_22918(mat, x1, y, z2).method_1336(r, g, b, a);
            vertexConsumer.method_22918(mat, x2, y, z2).method_1336(r, g, b, a);
            vertexConsumer.method_22918(mat, x2, y, z1).method_1336(r, g, b, a);
        }

        matrices.method_22909();

        // Flush immediately while the 3D camera matrices are still active.
        if (context.consumers() instanceof class_4597.class_4598 immediate) {
            immediate.method_22994(layer);
        }
    }

    // ── Color math ────────────────────────────────────────────────────────────

    /**
     * Maps walk count to an RGBA color array (each value 0–255).
     *
     * Four-stop heat-map gradient (light → heavy use):
     *   t = 0.00  →  green   (  0, 255, 0)  barely walked
     *   t = 0.33  →  yellow  (255, 255, 0)
     *   t = 0.67  →  orange  (255, 128, 0)
     *   t = 1.00  →  red     (255,   0, 0)  heavily walked
     *
     * Alpha also scales with use: 50 (faint) → 180 (solid).
     */
    private static int[] computeColor(int count) {
        int   minCount = WalkDataStore.MIN_WALK_THRESHOLD;
        int   maxCount = WalkDataStore.MAX_WALK_COUNT;
        float t = Math.min(1.0f, (float)(count - minCount) / (float)(maxCount - minCount));

        int r, g;
        final float third = 1.0f / 3.0f;

        if (t < third) {
            float s = t / third;
            r = Math.round(255 * s);
            g = 255;
        } else {
            float s = (t - third) / (2.0f * third);
            r = 255;
            g = Math.round(255 * (1.0f - s));
        }

        int a = Math.round(50 + 130 * t);

        return new int[]{r, g, 0, a};
    }

    /**
     * Maps block age (in-game days since last visited) to an RGBA color array.
     *
     * Three-stop gradient (young → old):
     *   t = 0.00  →  green  (  0, 220,  80)  just visited
     *   t = 0.50  →  cyan   (  0, 200, 220)
     *   t = 1.00  →  dark blue (0,  40, 160)  old
     *
     * Alpha fades slightly with age: 200 (vivid) → 120 (dim).
     */
    private static int[] computeExplorerColor(long ageDays) {
        float t = Math.min(1.0f, (float) ageDays / (float) WalkDataStore.EXPLORER_GRADIENT_DAYS);

        int g, b;
        if (t < 0.5f) {
            float s = t * 2f;
            g = Math.round(220 - 20 * s);   // 220 → 200
            b = Math.round(80  + 140 * s);  //  80 → 220
        } else {
            float s = (t - 0.5f) * 2f;
            g = Math.round(200 - 160 * s);  // 200 →  40
            b = Math.round(220 -  60 * s);  // 220 → 160
        }
        int a = Math.round(200 - 80 * t);   // 200 → 120

        return new int[]{0, g, b, a};
    }

}
