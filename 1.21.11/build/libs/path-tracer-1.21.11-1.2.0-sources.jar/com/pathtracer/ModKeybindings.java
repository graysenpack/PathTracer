package com.pathtracer;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

/**
 * Registers keybinds for Path Tracer.
 *
 *   H               — Toggle path overlay on/off
 *   (unbound)       — Clear path data within clear radius in the current dimension
 *
 * Both appear in Options → Controls → Path Tracer and can be rebound.
 */
@Environment(EnvType.CLIENT)
public class ModKeybindings {

    public static class_304 toggleOverlay;
    public static class_304 clearArea;
    public static class_304 toggleMode;

    public static void register() {
        var category = class_304.class_11900.method_74698(
                class_2960.method_60655("path-tracer", "controls"));

        toggleOverlay = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.path-tracer.toggle",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_H,
                category));

        clearArea = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.path-tracer.clear_area",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_UNKNOWN,
                category));

        toggleMode = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.path-tracer.toggle_mode",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_UNKNOWN,   // unbound by default
                category));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleOverlay.method_1436()) {
                PathRenderer.toggleOverlay();
            }
            while (toggleMode.method_1436()) {
                PathTracerConfig.explorerMode = !PathTracerConfig.explorerMode;
                PathTracerConfig.save();
                if (client.field_1724 != null) {
                    String msg = PathTracerConfig.explorerMode
                            ? "§b[PathTracer] Explorer Mode"
                            : "§a[PathTracer] Path Building Mode";
                    client.field_1724.method_7353(class_2561.method_43470(msg), true);
                }
            }
            while (clearArea.method_1436()) {
                if (client.field_1724 == null) return;
                class_2338 center  = client.field_1724.method_24515();
                int      removed = WalkDataStore.getInstance().clearArea(center);
                client.field_1724.method_7353(
                        class_2561.method_43470("§6[PathTracer] Cleared " + removed
                                + " entries within " + WalkDataStore.CLEAR_RADIUS
                                + " blocks (current dimension)"),
                        true);
            }
        });
    }
}
