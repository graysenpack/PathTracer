package com.pathtracer;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.gui.widget.TextWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * Config screen for Path Tracer — three tabs:
 *
 *   General       — mode toggle, shared settings, hotkeys, delete
 *   Path Mode     — footprint size, min/max passes, max age
 *   Explorer Mode — gradient days, max age
 *
 * Clicking a hotkey button enters listen mode; the next key press is bound.
 * Pressing Escape while in listen mode cancels.
 */
@Environment(EnvType.CLIENT)
public class PathTracerConfigScreen extends Screen {

    // ── Layout ────────────────────────────────────────────────────────────────
    private static final int TAB_Y      = 28;
    private static final int CONTENT_Y  = 56;
    private static final int ROW_HEIGHT = 30;
    private static final int FIELD_W    = 80;
    private static final int FIELD_H    = 20;
    private static final int KEY_BTN_W  = 130;
    private static final String[] FOOTPRINT_LABELS = {"1×1", "3×3", "5×5"};

    // ── State ─────────────────────────────────────────────────────────────────
    private final Screen   parent;
    private int            activeTab          = 0;
    private KeyBinding     activelyRebinding  = null;

    // Working values (survive tab switches; clamped on save)
    private boolean workingExplorerMode;
    private int     workingRenderRadius;
    private int     workingClearRadius;
    private boolean workingTrackOthers;
    private int     workingFootprint;
    private int     workingMinPasses;
    private int     workingMaxPasses;
    private int     workingPathMaxAge;
    private int     workingGradientDays;
    private int     workingExplorerMaxAge;

    public PathTracerConfigScreen(Screen parent) {
        super(Text.literal("Path Tracer Settings"));
        this.parent           = parent;
        workingExplorerMode   = PathTracerConfig.explorerMode;
        workingRenderRadius   = PathTracerConfig.renderRadius;
        workingClearRadius    = PathTracerConfig.clearRadius;
        workingTrackOthers    = PathTracerConfig.trackOtherPlayers;
        workingFootprint      = PathTracerConfig.footprintRadius;
        workingMinPasses      = PathTracerConfig.minPassCount;
        workingMaxPasses      = PathTracerConfig.maxPassCount;
        workingPathMaxAge     = PathTracerConfig.maxAgeDays;
        workingGradientDays   = PathTracerConfig.explorerGradientDays;
        workingExplorerMaxAge = PathTracerConfig.explorerMaxAgeDays;
    }

    // ── Init ─────────────────────────────────────────────────────────────────

    @Override
    protected void init() {
        int cx = this.width / 2;

        // Title
        int tw = textRenderer.getWidth(this.title);
        addDrawableChild(new TextWidget(cx - tw / 2, 10, tw + 2, 10, this.title, textRenderer));

        // Tab buttons — active tab is bolded + underlined and non-clickable
        String[] names = {"General", "Path Mode", "Explorer Mode"};
        int tabW = this.width / 3;
        for (int i = 0; i < 3; i++) {
            final int tab = i;
            boolean active = (activeTab == i);
            ButtonWidget btn = ButtonWidget.builder(
                            Text.literal(active ? "§l§n" + names[i] : names[i]),
                            b -> switchTab(tab))
                    .position(i * tabW, TAB_Y)
                    .size(i < 2 ? tabW : this.width - i * tabW, 20)
                    .build();
            btn.active = !active;
            addDrawableChild(btn);
        }

        switch (activeTab) {
            case 0 -> buildGeneralTab(cx);
            case 1 -> buildPathTab(cx);
            case 2 -> buildExplorerTab(cx);
        }
    }

    // ── Tab content ───────────────────────────────────────────────────────────

    private void buildGeneralTab(int cx) {
        int y = CONTENT_Y;

        String desc = "Path Mode: heat map of activity.  Explorer Mode: age-based trail.";
        int dw = textRenderer.getWidth(desc);
        addDrawableChild(new TextWidget(cx - dw / 2, y, dw + 2, 10,
                Text.literal(desc), textRenderer));
        y += 14;

        // Mode toggle
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Mode: " + (workingExplorerMode ? "§bExplorer" : "§aPath Building")),
                btn -> {
                    workingExplorerMode = !workingExplorerMode;
                    btn.setMessage(Text.literal("Mode: " +
                            (workingExplorerMode ? "§bExplorer" : "§aPath Building")));
                })
                .position(cx - 100, y).size(200, 20).build());
        y += ROW_HEIGHT;

        lf(cx, y, "Render Radius (blocks)", workingRenderRadius,
                PathTracerConfig.RENDER_RADIUS_MIN, PathTracerConfig.RENDER_RADIUS_MAX,
                v -> workingRenderRadius = v);
        y += ROW_HEIGHT;

        lf(cx, y, "Clear Radius (blocks)", workingClearRadius,
                PathTracerConfig.CLEAR_RADIUS_MIN, PathTracerConfig.CLEAR_RADIUS_MAX,
                v -> workingClearRadius = v);
        y += ROW_HEIGHT;

        kb(cx, y, "Show / Hide Overlay", ModKeybindings.toggleOverlay); y += ROW_HEIGHT;
        kb(cx, y, "Clear Nearby Paths",  ModKeybindings.clearArea);     y += ROW_HEIGHT;
        kb(cx, y, "Toggle Mode",          ModKeybindings.toggleMode);    y += ROW_HEIGHT;

        // Other Players
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Other Players: " + (workingTrackOthers ? "§aON" : "§cOFF")),
                btn -> {
                    workingTrackOthers = !workingTrackOthers;
                    btn.setMessage(Text.literal("Other Players: " +
                            (workingTrackOthers ? "§aON" : "§cOFF")));
                })
                .position(cx - 100, y).size(200, 20).build());
        y += ROW_HEIGHT;

        // Delete All Paths
        addDrawableChild(ButtonWidget.builder(Text.literal("§cDelete All Paths"), btn -> {
            WalkDataStore.getInstance().clearAllDimensions();
            btn.setMessage(Text.literal("§aAll paths deleted!"));
            btn.active = false;
        }).position(cx - 100, y).size(200, 20).build());
        y += ROW_HEIGHT;

        done(cx, y);
    }

    private void buildPathTab(int cx) {
        int y = CONTENT_Y;

        // Footprint Size cycle button
        lbl(cx, y - 10, "Footprint Size");
        addDrawableChild(ButtonWidget.builder(
                Text.literal(FOOTPRINT_LABELS[workingFootprint]),
                btn -> {
                    workingFootprint = (workingFootprint + 1) % 3;
                    btn.setMessage(Text.literal(FOOTPRINT_LABELS[workingFootprint]));
                })
                .position(cx - FIELD_W / 2, y).size(FIELD_W, FIELD_H).build());
        y += ROW_HEIGHT;

        lf(cx, y, "Min Passes", workingMinPasses,
                PathTracerConfig.PASS_COUNT_MIN, PathTracerConfig.PASS_COUNT_MAX,
                v -> workingMinPasses = v);
        y += ROW_HEIGHT;

        lf(cx, y, "Max Passes", workingMaxPasses,
                PathTracerConfig.PASS_COUNT_MIN, PathTracerConfig.PASS_COUNT_MAX,
                v -> workingMaxPasses = v);
        y += ROW_HEIGHT;

        lf(cx, y, "Max Age — Path Mode (days)", workingPathMaxAge,
                PathTracerConfig.MAX_AGE_DAYS_MIN, PathTracerConfig.MAX_AGE_DAYS_MAX,
                v -> workingPathMaxAge = v);
        y += ROW_HEIGHT;

        done(cx, y);
    }

    private void buildExplorerTab(int cx) {
        int y = CONTENT_Y;

        lf(cx, y, "Gradient Days (max 14)", workingGradientDays,
                PathTracerConfig.EXPLORER_GRADIENT_MIN, PathTracerConfig.EXPLORER_GRADIENT_MAX,
                v -> workingGradientDays = v);
        y += ROW_HEIGHT;

        lf(cx, y, "Max Age — Explorer Mode (days)", workingExplorerMaxAge,
                PathTracerConfig.EXPLORER_MAX_AGE_MIN, PathTracerConfig.EXPLORER_MAX_AGE_MAX,
                v -> workingExplorerMaxAge = v);
        y += ROW_HEIGHT;

        done(cx, y);
    }

    // ── Widget helpers ────────────────────────────────────────────────────────

    /** Centered label at y. */
    private void lbl(int cx, int y, String text) {
        int w = textRenderer.getWidth(text);
        addDrawableChild(new TextWidget(cx - w / 2, y, w + 2, 10,
                Text.literal(text), textRenderer));
    }

    /** Label at y-10, text field at y. Live setter called as user types. */
    private void lf(int cx, int y, String label, int initial, int min, int max, IntSetter setter) {
        lbl(cx, y - 10, label);
        TextFieldWidget f = new TextFieldWidget(
                textRenderer, cx - FIELD_W / 2, y, FIELD_W, FIELD_H, Text.empty());
        f.setMaxLength(5);
        f.setText(String.valueOf(initial));
        f.setTextPredicate(s -> s.matches("\\d*"));
        f.setChangedListener(s -> {
            try { setter.set(Integer.parseInt(s)); }
            catch (NumberFormatException ignored) {}
        });
        addDrawableChild(f);
    }

    /** Label at y-10, hotkey button at y. */
    private void kb(int cx, int y, String label, KeyBinding binding) {
        lbl(cx, y - 10, label);
        boolean listening = (activelyRebinding == binding);
        addDrawableChild(ButtonWidget.builder(
                listening ? Text.literal("§ePress a key…") : binding.getBoundKeyLocalizedText(),
                btn -> {
                    activelyRebinding = (activelyRebinding == binding) ? null : binding;
                    switchTab(activeTab);
                })
                .position(cx - KEY_BTN_W / 2, y).size(KEY_BTN_W, FIELD_H).build());
    }

    private void done(int cx, int y) {
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), btn -> saveAndClose())
                .position(cx - 75, y).size(150, 20).build());
    }

    // ── Key capture ───────────────────────────────────────────────────────────

    @Override
    public boolean keyPressed(KeyInput input) {
        if (activelyRebinding != null) {
            if (input.key() != GLFW.GLFW_KEY_ESCAPE) {
                activelyRebinding.setBoundKey(InputUtil.fromKeyCode(input));
                KeyBinding.updateKeysByCode();
                if (client != null) client.options.write();
            }
            activelyRebinding = null;
            switchTab(activeTab);
            return true;
        }
        return super.keyPressed(input);
    }

    // ── Navigation ────────────────────────────────────────────────────────────

    private void switchTab(int tab) {
        activeTab = tab;
        clearAndInit();
    }

    private void saveAndClose() {
        PathTracerConfig.explorerMode         = workingExplorerMode;
        PathTracerConfig.renderRadius         = clamp(workingRenderRadius, PathTracerConfig.RENDER_RADIUS_MIN, PathTracerConfig.RENDER_RADIUS_MAX);
        PathTracerConfig.clearRadius          = clamp(workingClearRadius,  PathTracerConfig.CLEAR_RADIUS_MIN,  PathTracerConfig.CLEAR_RADIUS_MAX);
        PathTracerConfig.trackOtherPlayers    = workingTrackOthers;
        PathTracerConfig.footprintRadius      = workingFootprint;
        PathTracerConfig.minPassCount         = clamp(workingMinPasses, PathTracerConfig.PASS_COUNT_MIN, PathTracerConfig.PASS_COUNT_MAX);
        PathTracerConfig.maxPassCount         = Math.max(PathTracerConfig.minPassCount,
                clamp(workingMaxPasses, PathTracerConfig.PASS_COUNT_MIN, PathTracerConfig.PASS_COUNT_MAX));
        PathTracerConfig.maxAgeDays           = clamp(workingPathMaxAge,     PathTracerConfig.MAX_AGE_DAYS_MIN,       PathTracerConfig.MAX_AGE_DAYS_MAX);
        PathTracerConfig.explorerGradientDays = clamp(workingGradientDays,   PathTracerConfig.EXPLORER_GRADIENT_MIN,  PathTracerConfig.EXPLORER_GRADIENT_MAX);
        PathTracerConfig.explorerMaxAgeDays   = clamp(workingExplorerMaxAge, PathTracerConfig.EXPLORER_MAX_AGE_MIN,   PathTracerConfig.EXPLORER_MAX_AGE_MAX);
        PathTracerConfig.save();
        close();
    }

    private static int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        if (client != null) client.setScreen(parent);
    }

    @FunctionalInterface private interface IntSetter { void set(int v); }
}
