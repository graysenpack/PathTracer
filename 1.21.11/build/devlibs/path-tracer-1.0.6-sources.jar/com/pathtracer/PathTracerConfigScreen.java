package com.pathtracer;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/**
 * Vanilla config screen for Path Tracer, opened via Mod Menu.
 *
 * Layout per setting row (ROW_HEIGHT = 40 px):
 *
 *   y - 10  ── label text centred
 *   y       ── [-]  value text  [+]   (buttons are 20 × 20)
 *
 * Settings:
 *   - Min Walk Threshold  ( 1 –  20) : walks needed before a block appears
 *   - Max Walk Count      ( 5 – 100) : walk count for full-green colour
 *   - Render Radius       (16 – 256) : horizontal block radius drawn around player
 *   - Max Age             ( 1 – 365) : in-game days before an entry is pruned
 */
@Environment(EnvType.CLIENT)
public class PathTracerConfigScreen extends Screen {

    private static final int TITLE_COLOR = 0xFFFFFF;
    private static final int LABEL_COLOR = 0xA0A0A0;
    private static final int VALUE_COLOR = 0xFFD700;  // gold

    /** Vertical distance between the button rows of successive settings. */
    private static final int ROW_HEIGHT  = 40;
    /** Y coordinate of the first setting row's buttons. */
    private static final int FIRST_ROW_Y = 75;

    private static final int BTN_W       = 20;
    private static final int BTN_H       = 20;
    /** Width of the number gap between the − and + buttons. */
    private static final int VALUE_GAP   = 44;

    private final Screen parent;

    // Working copies — only written to config when Done is pressed
    private int minWalkThreshold;
    private int maxWalkCount;
    private int renderRadius;
    private int maxAgeDays;

    public PathTracerConfigScreen(Screen parent) {
        super(Text.literal("Path Tracer Settings"));
        this.parent = parent;

        this.minWalkThreshold = PathTracerConfig.minWalkThreshold;
        this.maxWalkCount     = PathTracerConfig.maxWalkCount;
        this.renderRadius     = PathTracerConfig.renderRadius;
        this.maxAgeDays       = PathTracerConfig.maxAgeDays;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;

        addSettingRow(cx, rowY(0),
                PathTracerConfig.MIN_WALK_THRESHOLD_MIN,
                PathTracerConfig.MIN_WALK_THRESHOLD_MAX,
                delta -> minWalkThreshold = clamp(minWalkThreshold + delta,
                        PathTracerConfig.MIN_WALK_THRESHOLD_MIN,
                        PathTracerConfig.MIN_WALK_THRESHOLD_MAX));

        addSettingRow(cx, rowY(1),
                PathTracerConfig.MAX_WALK_COUNT_MIN,
                PathTracerConfig.MAX_WALK_COUNT_MAX,
                delta -> maxWalkCount = clamp(maxWalkCount + delta,
                        PathTracerConfig.MAX_WALK_COUNT_MIN,
                        PathTracerConfig.MAX_WALK_COUNT_MAX));

        addSettingRow(cx, rowY(2),
                PathTracerConfig.RENDER_RADIUS_MIN,
                PathTracerConfig.RENDER_RADIUS_MAX,
                delta -> renderRadius = clamp(renderRadius + delta,
                        PathTracerConfig.RENDER_RADIUS_MIN,
                        PathTracerConfig.RENDER_RADIUS_MAX));

        addSettingRow(cx, rowY(3),
                PathTracerConfig.MAX_AGE_DAYS_MIN,
                PathTracerConfig.MAX_AGE_DAYS_MAX,
                delta -> maxAgeDays = clamp(maxAgeDays + delta,
                        PathTracerConfig.MAX_AGE_DAYS_MIN,
                        PathTracerConfig.MAX_AGE_DAYS_MAX));

        // Done button — 30 px below the last row's buttons
        int doneY = rowY(3) + BTN_H + 18;
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), btn -> saveAndClose())
                .position(cx - 75, doneY)
                .size(150, 20)
                .build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Draw text FIRST so it isn't buried by rendering mixins (Architectury,
        // Fabric Screen API) that wrap super.render() and composite afterwards.
        // Buttons render on top which is the correct visual layering anyway.
        int cx = this.width / 2;

        context.drawCenteredTextWithShadow(textRenderer, this.title, cx, 20, TITLE_COLOR);

        renderSettingRow(context, cx, rowY(0), "Min Walk Threshold",     minWalkThreshold);
        renderSettingRow(context, cx, rowY(1), "Max Walk Count",         maxWalkCount);
        renderSettingRow(context, cx, rowY(2), "Render Radius (blocks)", renderRadius);
        renderSettingRow(context, cx, rowY(3), "Max Age (in-game days)", maxAgeDays);

        super.render(context, mouseX, mouseY, delta);   // renders child widgets (buttons)
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /** Y coordinate of the button row for setting index {@code i}. */
    private int rowY(int i) {
        return FIRST_ROW_Y + i * ROW_HEIGHT;
    }

    /**
     * Add the − and + buttons for one setting row centred at {@code cx}.
     * The gap between them is where the current value is rendered as text.
     *
     *   [−]  ← BTN_W px →  gap  ← BTN_W px →  [+]
     *        ^                                ^
     *    cx - halfSpan                    cx + halfSpan - BTN_W
     */
    private void addSettingRow(int cx, int y, int min, int max, IntConsumer onChange) {
        int halfSpan = BTN_W + VALUE_GAP / 2;

        addDrawableChild(ButtonWidget.builder(Text.literal("−"), btn -> onChange.accept(-1))
                .position(cx - halfSpan, y)
                .size(BTN_W, BTN_H)
                .build());

        addDrawableChild(ButtonWidget.builder(Text.literal("+"), btn -> onChange.accept(1))
                .position(cx + halfSpan - BTN_W, y)
                .size(BTN_W, BTN_H)
                .build());
    }

    /** Draw the label (above) and current value (centred in the button gap). */
    private void renderSettingRow(DrawContext context, int cx, int y,
                                  String label, int value) {
        // Label sits 11 px above the button row
        context.drawCenteredTextWithShadow(textRenderer, Text.literal(label),
                cx, y - 11, LABEL_COLOR);

        // Value is centred in the gap between − and + buttons
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal(String.valueOf(value)),
                cx, y + 6, VALUE_COLOR);
    }

    private void saveAndClose() {
        PathTracerConfig.minWalkThreshold = minWalkThreshold;
        PathTracerConfig.maxWalkCount     = maxWalkCount;
        PathTracerConfig.renderRadius     = renderRadius;
        PathTracerConfig.maxAgeDays       = maxAgeDays;
        PathTracerConfig.save();
        close();
    }

    private static int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }

    @Override
    public void close() {
        if (client != null) client.setScreen(parent);
    }

    @FunctionalInterface
    private interface IntConsumer { void accept(int delta); }
}
