package com.pathtracer;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.systems.ProjectionType;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.Tessellator;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Renders a colored overlay on top of blocks the player has walked on.
 *
 * Color gradient (all values tweakable in WalkDataStore):
 *   - Below MIN_WALK_THRESHOLD  →  invisible
 *   - At MIN_WALK_THRESHOLD     →  faint green   (0,   255, 0, alpha ~50)
 *   - At MAX_WALK_COUNT         →  bright red    (255,   0, 0, alpha ~180)
 *
 * Iris shader compatibility: we snapshot the 3D projection + camera matrices
 * at START_MAIN (before Iris runs its composite passes), then draw in
 * HudRenderCallback which fires after Iris has fully composited the world.
 * This prevents our overlay from being buried under Iris's output.
 */
@Environment(EnvType.CLIENT)
public class PathRenderer {

    private static boolean overlayEnabled = true;

    // Saved at START_MAIN so HudRenderCallback can restore them for 3D rendering.
    private static GpuBufferSlice savedProjectionMatrix = null;
    private static ProjectionType  savedProjectionType  = null;
    private static final Matrix4f  savedModelView       = new Matrix4f();
    private static Vec3d           savedCamPos          = Vec3d.ZERO;

    public static void toggleOverlay() {
        overlayEnabled = !overlayEnabled;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) {
            String state = overlayEnabled ? "§aEnabled" : "§cDisabled";
            client.player.sendMessage(Text.literal("[PathTracer] Overlay " + state), true);
        }
    }

    public static boolean isOverlayEnabled() {
        return overlayEnabled;
    }

    public static void register() {
        // Snapshot 3D matrices before Iris's composite passes overwrite the frame.
        WorldRenderEvents.START_MAIN.register(context -> {
            savedProjectionMatrix = RenderSystem.getProjectionMatrixBuffer();
            savedProjectionType   = RenderSystem.getProjectionType();
            savedModelView.set(RenderSystem.getModelViewMatrix());
            savedCamPos = context.worldState().cameraRenderState.pos;
        });

        // Draw after Iris has fully composited — our quads end up on top.
        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> renderOverlay());
    }

    // ── Core render logic ─────────────────────────────────────────────────────

    private static void renderOverlay() {
        if (!overlayEnabled) return;
        if (savedProjectionMatrix == null) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;

        Map<BlockPos, WalkData> walkMap = WalkDataStore.getInstance().getWalkMap();
        if (walkMap.isEmpty()) return;

        BlockPos playerPos = client.player.getBlockPos();
        int      radius    = WalkDataStore.RENDER_RADIUS;
        int      minWalks  = WalkDataStore.MIN_WALK_THRESHOLD;

        List<Map.Entry<BlockPos, WalkData>> toRender = new ArrayList<>();
        for (Map.Entry<BlockPos, WalkData> entry : walkMap.entrySet()) {
            BlockPos pos  = entry.getKey();
            WalkData data = entry.getValue();
            if (data.getCount() < minWalks) continue;
            if (Math.abs(pos.getX() - playerPos.getX()) > radius) continue;
            if (Math.abs(pos.getZ() - playerPos.getZ()) > radius) continue;
            toRender.add(entry);
        }
        if (toRender.isEmpty()) return;

        // Switch from HUD's 2D orthographic projection back to the 3D perspective
        // captured at world-render time.
        RenderSystem.backupProjectionMatrix();
        RenderSystem.setProjectionMatrix(savedProjectionMatrix, savedProjectionType);

        // Restore the camera view matrix so camera-relative coordinates project correctly.
        RenderSystem.getModelViewStack().pushMatrix();
        RenderSystem.getModelViewStack().set(savedModelView);

        // Build quads using camera-relative world-space coordinates.
        // RenderLayer.draw() applies the render pipeline (blend, depth) internally.
        Tessellator tessellator = Tessellator.getInstance();
        var layer  = RenderLayers.debugFilledBox();
        var buffer = tessellator.begin(layer.getDrawMode(), layer.getVertexFormat());

        Vec3d cam = savedCamPos;
        for (Map.Entry<BlockPos, WalkData> entry : toRender) {
            BlockPos pos   = entry.getKey();
            WalkData data  = entry.getValue();
            int[]    color = computeColor(data.getCount());
            int      r = color[0], g = color[1], b = color[2], a = color[3];

            float x1 = pos.getX() - (float) cam.x;
            float y  = pos.getY() + 1.002f - (float) cam.y;
            float z1 = pos.getZ() - (float) cam.z;
            float x2 = x1 + 1.0f;
            float z2 = z1 + 1.0f;

            buffer.vertex(x1, y, z1).color(r, g, b, a);
            buffer.vertex(x1, y, z2).color(r, g, b, a);
            buffer.vertex(x2, y, z2).color(r, g, b, a);
            buffer.vertex(x2, y, z1).color(r, g, b, a);
        }

        try (BuiltBuffer builtBuffer = buffer.end()) {
            layer.draw(builtBuffer);
        }

        RenderSystem.getModelViewStack().popMatrix();
        RenderSystem.restoreProjectionMatrix();
    }

    // ── Color math ────────────────────────────────────────────────────────────

    /**
     * Maps walk count to an RGBA color array (each value 0–255).
     *
     * Four-stop heat-map gradient (light → heavy use):
     *   t = 0.00  →  green   (  0, 255, 0)  barely walked
     *   t = 0.33  →  yellow  (255, 255, 0)
     *   t = 0.67  →  orange  (255, 128, 0)
     *   t = 1.00  →  red     (255,   0, 0)  heavily walked
     *
     * Alpha also scales with use: 50 (faint) → 180 (solid).
     */
    private static int[] computeColor(int count) {
        int   minCount = WalkDataStore.MIN_WALK_THRESHOLD;
        int   maxCount = WalkDataStore.MAX_WALK_COUNT;
        float t = Math.min(1.0f, (float)(count - minCount) / (float)(maxCount - minCount));

        int r, g;
        final float third = 1.0f / 3.0f;

        if (t < third) {
            float s = t / third;
            r = Math.round(255 * s);
            g = 255;
        } else {
            float s = (t - third) / (2.0f * third);
            r = 255;
            g = Math.round(255 * (1.0f - s));
        }

        int a = Math.round(50 + 130 * t);

        return new int[]{r, g, 0, a};
    }

}
