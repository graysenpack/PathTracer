package com.pathtracer;

import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.util.ARGB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Renders a colored overlay on top of blocks the player has walked on.
 * Updated for Minecraft 26.1 (official Mojang mappings).
 *
 * Uses RenderType.draw(MeshData) for immediate rendering at END_MAIN so
 * that the draw call fires while the 3D camera matrices are still active.
 * bufferSource() is intentionally avoided: in 26.1's deferred rendering
 * system it flushes at a later point when camera matrices may differ,
 * causing the overlay to float/drift.
 */
@Environment(EnvType.CLIENT)
public class PathRenderer {

    private static boolean overlayEnabled = true;

    private static final int BUFFER_CAPACITY = 4096 * 4 * (3 * 4 + 4);

    public static void toggleOverlay() {
        overlayEnabled = !overlayEnabled;
        Minecraft client = Minecraft.getInstance();
        if (client.player != null) {
            String state = overlayEnabled ? "§aEnabled" : "§cDisabled";
            client.player.sendOverlayMessage(
                    Component.literal("[PathTracer] Overlay " + state));
        }
    }

    public static boolean isOverlayEnabled() { return overlayEnabled; }

    public static void register() {
        LevelRenderEvents.END_MAIN.register(context -> renderOverlay(context));
    }

    // ── Core render logic ─────────────────────────────────────────────────────

    private static void renderOverlay(LevelRenderContext context) {
        if (!overlayEnabled) return;

        Minecraft client = Minecraft.getInstance();
        if (client.player == null || client.level == null) return;

        Map<BlockPos, WalkData> walkMap = WalkDataStore.getInstance().getWalkMap();
        if (walkMap.isEmpty()) return;

        // Camera-relative coordinates: subtract camera pos from each vertex so
        // RenderSystem's model-view (camera rotation) transforms them correctly.
        Vec3     cam       = context.levelState().cameraRenderState.pos;
        BlockPos playerPos = client.player.blockPosition();
        int      radius    = WalkDataStore.RENDER_RADIUS;
        int      minWalks  = WalkDataStore.MIN_WALK_THRESHOLD;

        List<Map.Entry<BlockPos, WalkData>> toRender = new ArrayList<>();
        for (Map.Entry<BlockPos, WalkData> entry : walkMap.entrySet()) {
            BlockPos pos  = entry.getKey();
            WalkData data = entry.getValue();

            if (data.getCount() < minWalks) continue;
            if (Math.abs(pos.getX() - playerPos.getX()) > radius) continue;
            if (Math.abs(pos.getZ() - playerPos.getZ()) > radius) continue;

            toRender.add(entry);
        }
        if (toRender.isEmpty()) return;

        // Draw immediately while the 3D projection and camera matrices are still
        // active. RenderType.draw() submits the GPU call inline; no deferred flush.
        try (ByteBufferBuilder byteBuffer = new ByteBufferBuilder(BUFFER_CAPACITY)) {
            BufferBuilder buffer = new BufferBuilder(
                    byteBuffer, VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);

            for (Map.Entry<BlockPos, WalkData> entry : toRender) {
                BlockPos pos   = entry.getKey();
                WalkData data  = entry.getValue();
                int      color = computeColor(data.getCount());

                float x1 = pos.getX() - (float) cam.x;
                float y  = pos.getY() + 1.002f - (float) cam.y;
                float z1 = pos.getZ() - (float) cam.z;
                float x2 = x1 + 1.0f;
                float z2 = z1 + 1.0f;

                buffer.addVertex(x1, y, z1).setColor(color);
                buffer.addVertex(x1, y, z2).setColor(color);
                buffer.addVertex(x2, y, z2).setColor(color);
                buffer.addVertex(x2, y, z1).setColor(color);
            }

            MeshData mesh = buffer.buildOrThrow();
            RenderTypes.debugFilledBox().draw(mesh);
        }
    }

    // ── Color math ────────────────────────────────────────────────────────────

    /**
     * Four-stop heat-map gradient, returned as a packed ARGB int:
     *   t = 0.00  →  green   (  0, 255, 0)
     *   t = 0.33  →  yellow  (255, 255, 0)
     *   t = 0.67  →  orange  (255, 128, 0)
     *   t = 1.00  →  red     (255,   0, 0)
     *
     * Alpha scales 50 → 180 with use.
     */
    private static int computeColor(int count) {
        int   minCount = WalkDataStore.MIN_WALK_THRESHOLD;
        int   maxCount = WalkDataStore.MAX_WALK_COUNT;
        float t = Math.min(1.0f, (float)(count - minCount) / (float)(maxCount - minCount));

        int r, g;
        final float third = 1.0f / 3.0f;

        if (t < third) {
            float s = t / third;
            r = Math.round(255 * s);
            g = 255;
        } else {
            float s = (t - third) / (2.0f * third);
            r = 255;
            g = Math.round(255 * (1.0f - s));
        }

        int a = Math.round(50 + 130 * t);

        return ARGB.color(a, r, g, 0);
    }

}
