package com.pathtracer;

import com.mojang.blaze3d.ProjectionType;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.util.ARGB;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Renders a colored overlay on top of blocks the player has walked on.
 * Updated for Minecraft 26.1 (official Mojang mappings).
 *
 * Iris shader compatibility: we snapshot the 3D projection + camera matrices
 * at START_MAIN (before Iris runs its composite passes), then draw via a
 * HudElement which fires after Iris has fully composited the world.
 * This prevents our overlay from being buried under Iris's output.
 */
@Environment(EnvType.CLIENT)
public class PathRenderer {

    private static boolean overlayEnabled = true;

    // Saved at START_MAIN so the HudElement can restore them for 3D rendering.
    private static GpuBufferSlice savedProjectionMatrix = null;
    private static ProjectionType  savedProjectionType  = null;
    private static final Matrix4f  savedModelView       = new Matrix4f();
    private static Vec3            savedCamPos          = Vec3.ZERO;

    // Reused buffer to avoid per-frame allocation; sized for ~4096 quads.
    private static final int BUFFER_CAPACITY = 4096 * 4 * (3 * 4 + 4);

    public static void toggleOverlay() {
        overlayEnabled = !overlayEnabled;
        Minecraft client = Minecraft.getInstance();
        if (client.player != null) {
            String state = overlayEnabled ? "§aEnabled" : "§cDisabled";
            client.player.sendOverlayMessage(
                    Component.literal("[PathTracer] Overlay " + state));
        }
    }

    public static boolean isOverlayEnabled() { return overlayEnabled; }

    public static void register() {
        // Snapshot 3D matrices before Iris's composite passes overwrite the frame.
        LevelRenderEvents.START_MAIN.register(context -> {
            savedProjectionMatrix = RenderSystem.getProjectionMatrixBuffer();
            savedProjectionType   = RenderSystem.getProjectionType();
            savedModelView.set(RenderSystem.getModelViewMatrix());
            savedCamPos = context.levelState().cameraRenderState.pos;
        });

        // HudElement fires after Iris has fully composited — our quads end up on top.
        HudElementRegistry.addLast(
                Identifier.fromNamespaceAndPath("path-tracer", "overlay"),
                (graphicsExtractor, deltaTracker) -> renderOverlay());
    }

    // ── Core render logic ─────────────────────────────────────────────────────

    private static void renderOverlay() {
        if (!overlayEnabled) return;
        if (savedProjectionMatrix == null) return;

        Minecraft client = Minecraft.getInstance();
        if (client.player == null || client.level == null) return;

        Map<BlockPos, WalkData> walkMap = WalkDataStore.getInstance().getWalkMap();
        if (walkMap.isEmpty()) return;

        BlockPos playerPos = client.player.blockPosition();
        int      radius    = WalkDataStore.RENDER_RADIUS;
        int      minWalks  = WalkDataStore.MIN_WALK_THRESHOLD;

        List<Map.Entry<BlockPos, WalkData>> toRender = new ArrayList<>();
        for (Map.Entry<BlockPos, WalkData> entry : walkMap.entrySet()) {
            BlockPos pos  = entry.getKey();
            WalkData data = entry.getValue();
            if (data.getCount() < minWalks) continue;
            if (Math.abs(pos.getX() - playerPos.getX()) > radius) continue;
            if (Math.abs(pos.getZ() - playerPos.getZ()) > radius) continue;
            toRender.add(entry);
        }
        if (toRender.isEmpty()) return;

        // Switch from HUD's 2D orthographic projection back to the 3D perspective
        // captured at world-render time.
        RenderSystem.backupProjectionMatrix();
        RenderSystem.setProjectionMatrix(savedProjectionMatrix, savedProjectionType);

        // Restore the camera view matrix so camera-relative coordinates project correctly.
        RenderSystem.getModelViewStack().pushMatrix();
        RenderSystem.getModelViewStack().set(savedModelView);

        // Build quads using camera-relative world-space coordinates.
        // RenderType.draw() applies the render pipeline (blend, depth) internally.
        Vec3 cam = savedCamPos;
        try (ByteBufferBuilder byteBuffer = new ByteBufferBuilder(BUFFER_CAPACITY)) {
            BufferBuilder buffer = new BufferBuilder(
                    byteBuffer, VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);

            for (Map.Entry<BlockPos, WalkData> entry : toRender) {
                BlockPos pos   = entry.getKey();
                WalkData data  = entry.getValue();
                int      color = computeColor(data.getCount());

                float x1 = pos.getX() - (float) cam.x;
                float y  = pos.getY() + 1.002f - (float) cam.y;
                float z1 = pos.getZ() - (float) cam.z;
                float x2 = x1 + 1.0f;
                float z2 = z1 + 1.0f;

                buffer.addVertex(x1, y, z1).setColor(color);
                buffer.addVertex(x1, y, z2).setColor(color);
                buffer.addVertex(x2, y, z2).setColor(color);
                buffer.addVertex(x2, y, z1).setColor(color);
            }

            MeshData mesh = buffer.buildOrThrow();
            RenderTypes.debugFilledBox().draw(mesh);
        }

        RenderSystem.getModelViewStack().popMatrix();
        RenderSystem.restoreProjectionMatrix();
    }

    // ── Color math ────────────────────────────────────────────────────────────

    /**
     * Four-stop heat-map gradient, returned as a packed ARGB int:
     *   t = 0.00  →  green   (  0, 255, 0)
     *   t = 0.33  →  yellow  (255, 255, 0)
     *   t = 0.67  →  orange  (255, 128, 0)
     *   t = 1.00  →  red     (255,   0, 0)
     *
     * Alpha scales 50 → 180 with use.
     */
    private static int computeColor(int count) {
        int   minCount = WalkDataStore.MIN_WALK_THRESHOLD;
        int   maxCount = WalkDataStore.MAX_WALK_COUNT;
        float t = Math.min(1.0f, (float)(count - minCount) / (float)(maxCount - minCount));

        int r, g;
        final float third = 1.0f / 3.0f;

        if (t < third) {
            float s = t / third;
            r = Math.round(255 * s);
            g = 255;
        } else {
            float s = (t - third) / (2.0f * third);
            r = 255;
            g = Math.round(255 * (1.0f - s));
        }

        int a = Math.round(50 + 130 * t);

        return ARGB.color(a, r, g, 0);
    }

}
